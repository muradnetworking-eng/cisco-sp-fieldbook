(() => {
  "use strict";

  const base = new URL("../", document.currentScript.src);
  const number = new Intl.NumberFormat("en", { maximumFractionDigits: 2 });
  const el = (tag, value) => {
    const node = document.createElement(tag);
    if (value !== undefined) node.textContent = value;
    return node;
  };

  function optionList(label, names) {
    const input = el("select");
    names.forEach((name, index) => {
      const option = el("option", name);
      option.value = String(index);
      input.append(option);
    });
    return control(label, input);
  }

  function numeric(label, value, min, max) {
    const input = el("input");
    input.type = "number";
    input.step = "any";
    input.required = true;
    input.min = String(min);
    if (max !== undefined) input.max = String(max);
    input.value = String(value);
    return control(label, input);
  }

  function control(label, input) {
    const wrapper = el("label", label);
    wrapper.append(input);
    return { wrapper, input };
  }

  function summarize(demand, paths, ceiling) {
    const cut = paths.reduce((total, path) => total + path.capacity, 0);
    const usable = paths.filter((path) => path.capacity > 0);
    const share = usable.length ? demand / usable.length : 0;
    const utilization = (capacity, load) => 100 * load / capacity;
    const percent = (capacity, load) => number.format(utilization(capacity, load)) + "%";
    if (!cut) return "Unavailable: no surviving capacity.";
    const pathsAboveCeiling = usable.filter((path) => utilization(path.capacity, share) > ceiling);
    const result = pathsAboveCeiling.length
      ? "Above ceiling: " + pathsAboveCeiling.map((path) => path.id).join(", ") + "."
      : "Within ceiling in this model.";
    const distribution = paths.map(({ id, capacity }) =>
      id + ": " + (capacity ? percent(capacity, share) : "down")
    ).join("; ");
    return "Cut: " + percent(cut, demand) + ". " + distribution + ". " + result;
  }

  async function mount(root) {
    try {
      const response = await fetch(new URL(root.dataset.fieldbookCapacity, base));
      if (!response.ok) throw new Error("Capacity data could not be loaded");
      const { defaults, designs, events, paths } = await response.json();
      const event = optionList("Failure or maintenance event", events.map((item) => item.label));
      const design = optionList("Capacity design", designs.map((item) => item.label));
      const east = numeric("East → west (Gbit/s)", defaults.eastToWest, 0);
      const west = numeric("West → east (Gbit/s)", defaults.westToEast, 0);
      const ceiling = numeric("Utilization ceiling (%)", defaults.ceiling, 1, 100);
      const controls = [event, design, east, west, ceiling];
      const group = el("fieldset");
      group.className = "fieldbook-capacity-inputs";
      group.append(el("legend", "Capacity test inputs"), ...controls.map((item) => item.wrapper));
      const report = el("div");
      report.setAttribute("role", "status");
      report.setAttribute("aria-atomic", "true");
      const reset = el("button", "Reset inputs");
      reset.className = "md-button";
      reset.type = "button";
      reset.addEventListener("click", () => {
        [event.input.value, design.input.value] = ["0", "0"];
        [east.input.value, west.input.value, ceiling.input.value] = [
          defaults.eastToWest, defaults.westToEast, defaults.ceiling
        ];
        update();
      });
      root.classList.add("fieldbook-card");
      root.replaceChildren(group, report, reset);
      controls.forEach(({ input }) => input.addEventListener("input", update));
      update();

      function update() {
        const inputs = [east.input, west.input, ceiling.input];
        if (inputs.some((input) => !input.validity.valid || !Number.isFinite(input.valueAsNumber))) {
          report.textContent = "Enter nonnegative demand and a ceiling from 1% to 100%.";
          return;
        }
        const selected = events[event.input.selectedIndex];
        const selectedDesign = designs[design.input.selectedIndex];
        const available = paths.map(({ id, members }) => ({
          id,
          capacity: members
            .filter((member) => (selectedDesign.includeUpgrades || !member.upgrade) && !selected.down.includes(member.id))
            .reduce((sum, member) => sum + member.gbps, 0)
        }));
        const [forward, reverse, target] = inputs.map((input) => input.valueAsNumber);
        const line = (direction, demand) => {
          const row = el("li");
          row.append(el("strong", direction + ": "), summarize(demand, available, target));
          return row;
        };
        const results = el("ul");
        results.append(line("East → west", forward), line("West → east", reverse));
        const survivor = available.map(({ id, capacity }) => id + " " + number.format(capacity) + " Gbit/s").join("; ");
        report.replaceChildren(el("p", selected.note + " Surviving capacity: " + survivor + "."), results);
      }
    } catch {
      root.textContent = "The interactive model could not load. Use the worked examples below.";
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("[data-fieldbook-capacity]").forEach(mount);
  });
})();
