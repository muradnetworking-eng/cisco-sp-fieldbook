(() => {
  "use strict";

  const base = new URL("../", document.currentScript.src);
  const storageKey = "sp-fieldbook:v1:" + base.pathname;
  const blank = () => ({ bookmarks: {}, completed: {}, scores: {}, recall: {} });
  let state = blank();
  const read = () => {
    try {
      return { ...blank(), ...JSON.parse(localStorage.getItem(storageKey)) };
    } catch {
      return state;
    }
  };
  state = read();

  function save() {
    try {
      localStorage.setItem(storageKey, JSON.stringify(state));
    } catch {
      // Study controls still work in the current page if browser storage is unavailable.
    }
  }

  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function button(label, action, secondary = false) {
    const node = element("button", label, "md-button" + (secondary ? "" : " md-button--primary"));
    node.type = "button";
    node.addEventListener("click", action);
    return node;
  }

  function link(label, route) {
    const node = element("a", label);
    node.href = new URL(route, base);
    return node;
  }

  function disclosure(label, child) {
    const node = element("details");
    node.append(element("summary", label), child);
    return node;
  }

  function announce(node, message) {
    node.textContent = message;
  }

  function addProgressControls() {
    const heading = document.querySelector(".md-content__inner > h1");
    const route = location.pathname.slice(base.pathname.length).replace(/index\.html$/, "");
    if (!heading || !route || route.startsWith("blog/")) return;

    const title = heading.textContent.replace(/¶$/, "").trim();
    const controls = element("div", undefined, "fieldbook-actions fieldbook-progress");
    const bookmark = button("Bookmark", () => {
      state = read();
      if (state.bookmarks[route]) delete state.bookmarks[route];
      else state.bookmarks[route] = title;
      save();
      update();
    }, true);
    const complete = button("Mark complete", () => {
      state = read();
      if (state.completed[route]) delete state.completed[route];
      else state.completed[route] = title;
      save();
      update();
    }, true);
    function update() {
      bookmark.textContent = state.bookmarks[route] ? "Bookmarked" : "Bookmark";
      bookmark.setAttribute("aria-pressed", String(Boolean(state.bookmarks[route])));
      complete.textContent = state.completed[route] ? "Completed" : "Mark complete";
      complete.setAttribute("aria-pressed", String(Boolean(state.completed[route])));
    }
    update();
    controls.append(bookmark, complete, button("Print page", () => window.print(), true));
    heading.after(controls);
  }

  function addDashboard() {
    const mount = document.querySelector("[data-fieldbook-dashboard]");
    if (!mount) return;
    for (const [title, records] of [["Bookmarks", state.bookmarks], ["Completed pages", state.completed]]) {
      mount.append(element("h3", title));
      const list = element("ul");
      for (const [route, label] of Object.entries(records)) {
        if (!/^[\w/-]+\/$/.test(route)) continue;
        const item = element("li");
        item.append(link(label, route));
        list.append(item);
      }
      mount.append(list.childElementCount ? list : element("p", "Your saved pages will appear here."));
    }
  }

  function navigator(mount, initialItems, render) {
    let position = 0;
    let items = initialItems;
    const counter = element("span", "", "fieldbook-count");
    counter.setAttribute("aria-live", "polite");
    const body = element("div");
    const previous = button("Previous", () => {
      position -= 1;
      update();
    }, true);
    const next = button("Next", () => {
      position += 1;
      update();
    });
    const actions = element("div", undefined, "fieldbook-actions");
    actions.append(previous, counter, next);
    mount.append(actions, body);

    function update() {
      announce(counter, items.length ? `${position + 1} of ${items.length}` : "0 results");
      previous.disabled = position === 0;
      next.disabled = position + 1 >= items.length;
      body.replaceChildren(items.length ? render(items[position]) : element("p", "No items match this filter."));
    }
    update();
    return (selection, { preservePosition = false } = {}) => {
      items = selection;
      position = preservePosition ? Math.min(position, Math.max(0, items.length - 1)) : 0;
      update();
    };
  }

  function interview(question) {
    const item = element("section");
    const notes = element("textarea");
    notes.rows = 4;
    const label = element("label", "Draft your reasoning");
    label.append(notes);
    item.append(element("h3", question.prompt), label);

    const solution = element("div");
    solution.append(element("p", question.answer, "fieldbook-prose"));
    const checklist = element("fieldset");
    checklist.append(element("legend", "Self-score against the rubric"));
    const saved = state.scores[question.id]?.checked ?? [];
    const checks = question.criteria.map((criterion, index) => {
      const row = element("label", undefined, "fieldbook-check");
      const box = element("input");
      box.type = "checkbox";
      box.checked = saved.includes(index);
      row.append(box, element("span", criterion));
      checklist.append(row);
      return box;
    });
    const score = element("p", "");
    score.setAttribute("role", "status");
    const review = link(question.review.label, question.review.url);
    const update = button("Save self-score", () => {
      const checked = checks.flatMap((box, index) => box.checked ? [index] : []);
      state = read();
      state.scores[question.id] = { checked };
      save();
      showScore(checked.length);
    });
    function showScore(points) {
      score.replaceChildren(document.createTextNode(`${points}/${checks.length} criteria met.`));
      if (points < checks.length) score.append(" Review ", review, ".");
    }
    if (state.scores[question.id]) showScore(saved.length);
    solution.append(checklist, update, score);
    item.append(disclosure("Reveal expected answer and rubric", solution));
    return item;
  }

  function troubleshooting(ticket) {
    const item = element("section");
    const evidence = element("pre", undefined, "fieldbook-evidence");
    evidence.append(element("code", ticket.evidence));
    item.append(element("h3", ticket.prompt), evidence, element("h4", "Choose an investigation"));
    for (const step of ticket.steps) {
      item.append(disclosure(step.label, element("p", step.result, "fieldbook-prose")));
    }
    item.append(disclosure("Reveal root cause and corrective action", element("p", ticket.answer, "fieldbook-prose")));
    return item;
  }

  function flashcard(card) {
    const item = element("section");
    const stats = element("p", "");
    stats.setAttribute("role", "status");
    const answer = element("div");
    const actions = element("div", undefined, "fieldbook-actions");
    function rate(result) {
      state = read();
      const count = state.recall[card.id] ?? { known: 0, missed: 0 };
      count[result] += 1;
      state.recall[card.id] = count;
      save();
      update();
    }
    function update() {
      const count = state.recall[card.id] ?? { known: 0, missed: 0 };
      announce(stats, `Recalled ${count.known} · Needs review ${count.missed}`);
    }
    actions.append(button("Recalled", () => rate("known")), button("Needs review", () => rate("missed"), true));
    answer.append(element("p", card.back, "fieldbook-prose"), actions, stats);
    item.append(
      element("h3", card.front), element("p", card.tags.join(" · "), "fieldbook-tags"),
      disclosure("Reveal answer", answer)
    );
    update();
    return item;
  }

  async function mountStudy(mount) {
    const topic = mount.dataset.fieldbookTopic;
    try {
      const response = await fetch(new URL(`data/${topic}.json`, base));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      const picker = element("div", undefined, "fieldbook-actions");
      const panel = element("div", undefined, "fieldbook-card");
      const modes = {
        "Mock interview": [data.interview, interview],
        "Troubleshooting drill": [data.troubleshooting, troubleshooting],
        "Flashcards": [data.cards, flashcard],
      };
      const controls = [];
      function select(mode) {
        panel.replaceChildren();
        for (const control of controls) control.setAttribute("aria-pressed", String(control.textContent === mode));
        const [items, render] = modes[mode];
        if (mode !== "Flashcards") {
          navigator(panel, items, render);
          return;
        }
        const label = element("label", "Filter by tag ");
        const filter = element("select");
        for (const tag of ["All tags", ...new Set(items.flatMap((card) => card.tags).sort())]) {
          filter.append(element("option", tag));
        }
        label.append(filter);
        panel.append(label);
        const show = navigator(panel, items, render);
        filter.addEventListener("change", () => {
          show(filter.selectedIndex === 0 ? items : items.filter((card) => card.tags.includes(filter.value)));
        });
      }
      for (const mode of Object.keys(modes)) {
        const control = button(mode, () => select(mode), true);
        controls.push(control);
        picker.append(control);
      }
      mount.replaceChildren(picker, panel);
      select(mount.dataset.fieldbookMode === "cards" ? "Flashcards" : "Mock interview");
    } catch {
      mount.replaceChildren(element("p", "Interactive exercises require the portal to be served over HTTP. Use the linked workbook and question bank for the static exercises."));
    }
  }

  async function mountTrace(mount) {
    try {
      const response = await fetch(new URL(`traces/${mount.dataset.fieldbookTrace}.json`, base));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const trace = await response.json();
      const panel = element("div", undefined, "fieldbook-card");
      const label = element("label", trace.selector_label + " ");
      const select = element("select");
      for (const variant of trace.variants) select.append(element("option", variant.title));
      label.append(select);
      panel.append(label);
      const steps = () => [...trace.common_steps, ...trace.variants[select.selectedIndex].steps];
      const show = navigator(panel, steps(), (step) => {
        const item = element("section");
        item.append(element("h3", step.hop), element("p", step.action, "fieldbook-tags"));
        if (step.stack?.length) {
          item.append(element("p", "On-wire label stack, top first", "fieldbook-stack-label"));
          const stack = element("ol", undefined, "fieldbook-label-stack");
          for (const value of step.stack) stack.append(element("li", String(value)));
          item.append(stack);
        } else if (step.stack) {
          item.append(element("p", "Unlabeled IPv4 packet"));
        }
        item.append(element("p", step.reason));
        return item;
      });
      select.addEventListener("change", () => show(steps(), { preservePosition: true }));
      mount.replaceChildren(panel);
    } catch {
      mount.textContent = "Serve the portal over HTTP to load this trace. The technical walkthrough covers the same stages.";
    }
  }

  async function renderDiagrams() {
    const diagrams = document.querySelectorAll("pre.fieldbook-diagram");
    if (!diagrams.length) return;
    await new Promise((resolve, reject) => {
      const script = element("script");
      script.src = new URL("assets/vendor/mermaid.min.js", base);
      script.onload = resolve;
      script.onerror = reject;
      document.head.append(script);
    });
    window.mermaid.initialize({ startOnLoad: false, securityLevel: "strict", theme: "neutral" });
    for (const [index, source] of [...diagrams].entries()) {
      try {
        const { svg } = await window.mermaid.render(`fieldbook-diagram-${index}`, source.textContent.trim());
        const figure = element("figure", undefined, "fieldbook-figure");
        const view = element("div", undefined, "fieldbook-diagram-view");
        view.tabIndex = 0;
        view.setAttribute("aria-label", "Scrollable network diagram");
        view.innerHTML = svg;
        const rendered = view.querySelector("svg");
        const actions = element("div", undefined, "fieldbook-actions");
        let zoom = 100;
        function resize(percent) {
          zoom = Math.min(250, Math.max(100, percent));
          rendered.style.width = `${zoom}%`;
          rendered.style.maxWidth = "none";
        }
        actions.append(button("Zoom in", () => resize(zoom + 25), true), button("Reset zoom", () => resize(100), true));
        source.before(figure);
        figure.append(view, actions, disclosure("Diagram source", source));
      } catch (error) {
        console.warn("Fieldbook diagram left as source.", error);
      }
    }
  }

  function highlightCisco() {
    const tokens = /^\s*[!#].*$|\b(?:show|configure|router|neighbor|address-family|route-policy|route-map|prefix-set|ip|ipv6|commit|rollback|exit|end|no|match|set|pass|drop|permit|deny|activate)\b|\b\d+(?:\.\d+){3}(?:\/\d+)?\b/gm;
    for (const code of document.querySelectorAll(".language-cisco > pre > code, code.language-cisco")) {
      const source = code.textContent;
      const highlighted = document.createDocumentFragment();
      let cursor = 0;
      for (const token of source.matchAll(tokens)) {
        highlighted.append(source.slice(cursor, token.index));
        const value = token[0];
        const kind = /^[!#]/.test(value.trimStart()) ? "comment" : /^\d/.test(value) ? "address" : "keyword";
        highlighted.append(element("span", value, "fieldbook-cli-" + kind));
        cursor = token.index + value.length;
      }
      highlighted.append(source.slice(cursor));
      code.replaceChildren(highlighted);
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    highlightCisco();
    addProgressControls();
    addDashboard();
    document.querySelectorAll("[data-fieldbook-topic]").forEach(mountStudy);
    document.querySelectorAll("[data-fieldbook-trace]").forEach(mountTrace);
    renderDiagrams().catch((error) => console.warn("Diagram runtime unavailable.", error));
  });
})();
