(() => {
  "use strict";

  const base = new URL("../", document.currentScript.src);

  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function button(label, action, primary = false) {
    const node = element("button", label, primary ? "md-button md-button--primary" : "md-button");
    node.type = "button";
    node.addEventListener("click", action);
    return node;
  }

  function link(label, path) {
    const node = element("a", label);
    node.href = new URL(path, base);
    return node;
  }

  function record(track) {
    const key = `sp-fieldbook:mock:v1:${base.pathname}:${track.id}`;
    const scores = new Map();
    try {
      const saved = JSON.parse(localStorage.getItem(key));
      if (saved?.revision === track.revision) {
        for (const q of track.questions) {
          const indexes = saved.scores?.[q.id];
          if (Array.isArray(indexes)) scores.set(q.id, [...new Set(indexes.filter(i =>
            Number.isInteger(i) && i >= 0 && i < q.criteria.length))]);
        }
      }
    } catch { /* The session works with in-memory scores if storage is unavailable. */ }
    return {
      scores,
      save() {
        try {
          localStorage.setItem(key, JSON.stringify({revision: track.revision, scores: Object.fromEntries(scores)}));
          return true;
        } catch { return false; }
      }
    };
  }

  function mountSession(mount, tracks) {
    const records = new Map(tracks.map(track => [track.id, record(track)]));
    const drafts = new Map(tracks.map(track => [track.id, new Map()]));
    const form = element("div", undefined, "fieldbook-card");
    const label = element("label", "Practice role ");
    const select = element("select");
    for (const track of tracks) select.add(new Option(track.title, track.id));
    label.append(select);
    const brief = element("p");
    const start = button("Start session", () => openTrack(), true);
    const selector = element("div", undefined, "fieldbook-actions");
    selector.append(label, start);
    form.append(selector, brief);

    const content = element("div", undefined, "fieldbook-card");
    content.hidden = true;
    const notices = element("p");
    notices.setAttribute("role", "status");
    mount.replaceChildren(form, content, notices);
    let track, saved, notes, position;

    function describe() {
      const current = tracks.find(item => item.id === select.value);
      const count = records.get(current.id).scores.size;
      brief.textContent = `${current.brief} ${current.minutes} minutes suggested · ${current.pass_percent}% practice threshold · ${count}/${current.questions.length} scores saved.`;
      start.textContent = count ? "Resume session" : "Start session";
    }

    function openTrack() {
      track = tracks.find(item => item.id === select.value);
      saved = records.get(track.id);
      notes = drafts.get(track.id);
      const first = track.questions.findIndex(q => !saved.scores.has(q.id));
      position = first < 0 ? track.questions.length : first;
      content.hidden = false;
      notices.textContent = "";
      render();
    }

    function move(target) {
      position = target;
      notices.textContent = "";
      render();
    }

    function render() {
      const complete = position === track.questions.length;
      const heading = element("h2", complete ? `${track.title}: practice result` : `Question ${position + 1} of ${track.questions.length}`);
      heading.tabIndex = -1;
      const actions = element("div", undefined, "fieldbook-actions");
      const prev = button("Previous question", () => move(position - 1));
      prev.disabled = position === 0;
      actions.append(prev);
      if (!complete) {
        const last = position + 1 === track.questions.length;
        actions.append(button(last ? "View results" : "Next question", () => move(position + 1), true));
        if (!last) actions.append(button("View results", () => move(track.questions.length)));
      }
      const reset = button("Restart this track", () => {
        if (!window.confirm("Clear the scores and draft notes for this role?")) return;
        saved.scores.clear();
        notes.clear();
        const persisted = saved.save();
        describe();
        move(0);
        notices.textContent = persisted ? "Track restarted." : "Track restarted on this page. Browser storage is unavailable.";
      });
      actions.append(reset);
      content.replaceChildren(heading, complete ? results() : question(track.questions[position]), actions);
      heading.focus();
    }

    function question(q) {
      const item = element("section");
      if (q.critical) item.append(element("p", "Critical question: at least one point required.", "fieldbook-tags"));
      item.append(element("p", q.prompt, "fieldbook-prose"));
      const label = element("label", "Draft your reasoning (optional)");
      const draft = element("textarea");
      draft.rows = 4;
      draft.value = notes.get(q.id) ?? "";
      draft.addEventListener("input", () => notes.set(q.id, draft.value));
      label.append(draft);
      item.append(label);
      if (q.followup) {
        const followup = element("details");
        followup.append(element("summary", "Role follow-up"), element("p", q.followup));
        item.append(followup);
      }

      const rubric = element("details");
      rubric.append(element("summary", "Reveal expected answer and rubric"), element("p", q.answer, "fieldbook-prose"));
      const fields = element("fieldset");
      fields.append(element("legend", "Mark each criterion you met"));
      const checks = q.criteria.map((criterion, i) => {
        const row = element("label", undefined, "fieldbook-check");
        const input = element("input");
        input.type = "checkbox";
        input.checked = saved.scores.get(q.id)?.includes(i) ?? false;
        row.append(input, element("span", criterion));
        fields.append(row);
        return input;
      });
      const score = element("p", saved.scores.has(q.id) ? `Saved: ${saved.scores.get(q.id).length}/${checks.length}` : "Not scored.");
      rubric.append(fields, button("Save score", () => {
        const checked = checks.flatMap((input, i) => input.checked ? [i] : []);
        saved.scores.set(q.id, checked);
        const persisted = saved.save();
        score.textContent = `Saved: ${checked.length}/${checks.length}`;
        notices.textContent = persisted ? `Saved question ${position + 1}: ${checked.length} of ${checks.length}.` :
          `Question ${position + 1}: ${checked.length} of ${checks.length} saved on this page only. Browser storage is unavailable.`;
        describe();
      }, true), score, link(q.review.label, q.review.url));
      item.append(rubric);
      return item;
    }

    function results() {
      const container = element("section");
      const possible = track.questions.reduce((sum, q) => sum + q.criteria.length, 0);
      const total = track.questions.reduce((sum, q) => sum + (saved.scores.get(q.id)?.length ?? 0), 0);
      const scored = saved.scores.size;
      const critical = track.questions.filter(q => q.critical && saved.scores.has(q.id) && saved.scores.get(q.id).length === 0);
      const met = total * 100 >= track.pass_percent * possible;
      const verdict = scored < track.questions.length ? "Incomplete" : met && !critical.length ? "Practice threshold met" : "Practice threshold not met";
      container.append(element("p", `${verdict} · ${total}/${possible} points · ${scored}/${track.questions.length} scored.`),
        element("p", `To pass this practice track, score at least ${track.pass_percent}% overall and one point on every critical question.`));
      const list = element("ol");
      track.questions.forEach((q, i) => {
        const current = saved.scores.get(q.id);
        const row = element("li");
        row.append(button(`Go to question ${i + 1}`, () => move(i)),
          current ? ` ${current.length}/${q.criteria.length}` : " Not scored",
          q.critical ? current?.length === 0 ? " · critical gate missed" : " · critical" : "");
        if (current && current.length < q.criteria.length) row.append(" · Review ", link(q.review.label, q.review.url));
        list.append(row);
      });
      container.append(list);
      return container;
    }

    select.addEventListener("change", () => {
      content.hidden = true;
      notices.textContent = "";
      describe();
    });
    describe();
  }

  document.addEventListener("DOMContentLoaded", async () => {
    const mount = document.querySelector("[data-fieldbook-mock]");
    if (!mount) return;
    try {
      const response = await fetch(new URL("data/interview-tracks.json", base));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (data.version !== 1 || !data.tracks?.length) throw new Error("Interview data unavailable");
      mountSession(mount, data.tracks);
    } catch {
      mount.replaceChildren(element("p", "Could not load the interview session. Reload this page or use the question banks below."));
    }
  });
})();
