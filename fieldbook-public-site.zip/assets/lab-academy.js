(() => {
  "use strict";

  const filters = [
    ["modes", "Run method", [
      ["offline", "Offline exercise"], ["cml", "CML starter"], ["manual", "Manual build"]
    ]],
    ["platforms", "Platform", [
      ["ios", "Cisco IOS"], ["ios-xe", "IOS XE"], ["ios-xr", "IOS XR"], ["nx-os", "NX-OS"], ["offline", "Local Python"]
    ]],
    ["evidence", "Evidence", [
      ["offline-check", "Offline check"], ["offline-run", "Offline run"], ["device-run", "Device run"],
      ["review-required", "Review Required"], ["conceptual", "Conceptual"]
    ]]
  ];

  function mount(catalog) {
    const controls = catalog.querySelector("[data-lab-controls]");
    const rows = Array.from(catalog.querySelectorAll(".fieldbook-lab-entry"));
    const form = document.createElement("form");
    form.className = "fieldbook-lab-filters";
    const status = document.createElement("p");
    status.setAttribute("role", "status");
    const selects = filters.map(([key, title, choices]) => {
      const label = document.createElement("label");
      label.textContent = title;
      const select = document.createElement("select");
      select.add(new Option("Any", ""));
      for (const [value, text] of choices) {
        if (rows.some(row => row.dataset[key].split(" ").includes(value))) select.add(new Option(text, value));
      }
      label.append(select);
      form.append(label);
      return [key, select];
    });
    const reset = document.createElement("button");
    reset.type = "button";
    reset.className = "md-button";
    reset.textContent = "Reset filters";
    form.append(reset);

    function update() {
      let count = 0;
      for (const row of rows) {
        row.hidden = !selects.every(([key, select]) => !select.value || row.dataset[key].split(" ").includes(select.value));
        if (!row.hidden) count++;
      }
      status.textContent = count === 0 ? "No labs match. Change a filter or reset the catalog." : `${count} of ${rows.length} labs`;
    }

    form.addEventListener("change", update);
    form.addEventListener("submit", event => event.preventDefault());
    reset.addEventListener("click", () => { form.reset(); update(); });
    controls.replaceChildren(form, status);
    update();
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("[data-fieldbook-lab-catalog]").forEach(mount);
  });
})();
