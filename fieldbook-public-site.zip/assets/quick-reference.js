(() => {
  "use strict";

  function node(tag, text) {
    const element = document.createElement(tag);
    if (text) element.textContent = text;
    return element;
  }

  function mount(directory) {
    const groups = [...directory.querySelectorAll("[data-reference-group]")];
    const rows = groups.flatMap(group => [...group.querySelectorAll("[data-reference-sheet]")].map(row =>
      ({group, row, text: row.textContent.toLowerCase()})));
    const form = node("form");
    form.className = "fieldbook-actions fieldbook-reference-controls";
    const label = node("label", "Filter command sheets");
    const input = node("input");
    input.type = "search";
    input.placeholder = "e.g. next hop, MTU, rollback";
    label.append(input);
    const reset = node("button", "Clear filter");
    reset.type = "button";
    reset.className = "md-button";
    form.append(label, reset);
    const status = node("p");
    status.setAttribute("role", "status");

    function filter() {
      const words = input.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
      const visible = new Set();
      let count = 0;
      for (const {group, row, text} of rows) {
        row.hidden = !words.every(word => text.includes(word));
        if (!row.hidden) {
          visible.add(group);
          count++;
        }
      }
      for (const group of groups) group.hidden = !visible.has(group);
      status.textContent = count ? `${count} of ${rows.length} sheets` : "No command sheets match. Try a shorter term or clear the filter.";
    }

    form.addEventListener("submit", event => event.preventDefault());
    input.addEventListener("input", filter);
    reset.addEventListener("click", () => { input.value = ""; filter(); input.focus(); });
    directory.querySelector("[data-reference-controls]").append(form, status);
    filter();
  }

  document.addEventListener("DOMContentLoaded", () => {
    for (const directory of document.querySelectorAll("[data-fieldbook-reference]")) mount(directory);
  });
})();
