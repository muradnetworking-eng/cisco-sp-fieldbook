// Local, fixed-interval recall schedule. Timestamps use Unix epoch milliseconds.
export const REVIEW_STEPS = Object.freeze([1, 3, 7, 14, 30]);

const DAY = 24 * 60 * 60 * 1000;
const RETRY_DELAY = 10 * 60 * 1000;
const MAX_TIMESTAMP = 8_640_000_000_000_000;

function timestamp(value) {
  return Number.isSafeInteger(value) && value >= 0 && value <= MAX_TIMESTAMP;
}

export function validRecord(record) {
  return record !== null && typeof record === "object" && !Array.isArray(record) &&
    Object.hasOwn(record, "stage") && Object.hasOwn(record, "due") &&
    Object.hasOwn(record, "lastReviewed") && Object.hasOwn(record, "grade") &&
    Number.isInteger(record.stage) && timestamp(record.due) && timestamp(record.lastReviewed) &&
    record.due >= record.lastReviewed &&
    (record.grade === "again" ? record.stage === 0 :
      record.grade === "recalled" && record.stage >= 1 && record.stage <= REVIEW_STEPS.length);
}

export function rateCard(previous, grade, now) {
  if (grade !== "again" && grade !== "recalled") throw new RangeError("Unknown flashcard grade");
  if (!timestamp(now)) throw new RangeError("Invalid review timestamp");
  const previousStage = validRecord(previous) ? previous.stage : 0;
  const stage = grade === "again" ? 0 : Math.min(previousStage + 1, REVIEW_STEPS.length);
  const delay = stage === 0 ? RETRY_DELAY : REVIEW_STEPS[stage - 1] * DAY;
  const due = now + delay;
  if (!timestamp(due)) throw new RangeError("Invalid flashcard due timestamp");
  return {stage, due, lastReviewed: now, grade};
}

export function selectDue(cards, records, now, limit) {
  if (!timestamp(now)) throw new RangeError("Invalid queue timestamp");
  if (!Number.isSafeInteger(limit) || limit < 0) throw new RangeError("Invalid review limit");
  const reviewed = [];
  const unseen = [];
  for (const [index, card] of cards.entries()) {
    const record = records && Object.hasOwn(records, card.id) ? records[card.id] : null;
    if (!validRecord(record)) unseen.push(card);
    else if (record.due <= now) reviewed.push({card, due: record.due, index});
  }
  reviewed.sort((a, b) => a.due - b.due || a.index - b.index);
  return [...reviewed.map(entry => entry.card), ...unseen].slice(0, limit);
}
