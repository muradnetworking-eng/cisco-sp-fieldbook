import { rateCard, selectDue, validRecord } from "./flashcard-schedule.mjs";

const base = new URL("../", import.meta.url);
const key = "sp-fieldbook:flashcards:v1:" + base.pathname;
const formatDate = new Intl.DateTimeFormat(undefined, {dateStyle: "medium", timeStyle: "short"});

function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function button(label, action, primary = false) {
  const node = element("button", label, primary ? "md-button md-button--primary" : "md-button");
  node.type = "button";
  node.addEventListener("click", action);
  return node;
}

function picker(label, options) {
  const row = element("label", label + " ");
  const select = element("select");
  for (const [value, text] of options) select.add(new Option(text, value));
  row.append(select);
  return [row, select];
}

function mountQueue(mount, decks) {
  const allCards = decks.flatMap(deck => deck.entries.map(card => ({...card, deck: deck.id, title: deck.title})));
  const knownIDs = new Set(allCards.map(card => card.id));
  const unsaved = new Map();

  function readRecords() {
    const result = Object.create(null);
    try {
      const value = JSON.parse(localStorage.getItem(key));
      for (const [id, record] of Object.entries(value?.records ?? {})) {
        if (knownIDs.has(id) && validRecord(record)) result[id] = record;
      }
    } catch { /* Start with in-memory results if local storage is unavailable. */ }
    for (const [id, value] of unsaved) result[id] = value;
    return result;
  }

  function saveRecord(card, grade, now) {
    const records = readRecords();
    const value = rateCard(records[card.id], grade, now);
    records[card.id] = value;
    try {
      localStorage.setItem(key, JSON.stringify({records}));
      unsaved.clear();
      return true;
    } catch {
      unsaved.set(card.id, value);
      return false;
    }
  }

  const [deckLabel, deckSelect] = picker("Deck", [["", "All decks"], ...decks.map(deck => [deck.id, deck.title])]);
  const [tagLabel, tagSelect] = picker("Exact tag", []);
  const [limitLabel, limitSelect] = picker("Cards per round", [10, 20, 40].map(n => [String(n), String(n)]));
  const preselected = new URL(location.href).searchParams.get("deck");
  if (decks.some(deck => deck.id === preselected)) deckSelect.value = preselected;

  const controls = element("div", undefined, "fieldbook-actions");
  const start = button("Start review", startRound, true);
  const refresh = button("Refresh due count", () => preview());
  controls.append(deckLabel, tagLabel, limitLabel, start, refresh);
  const settings = element("div", undefined, "fieldbook-card");
  settings.append(controls);

  const status = element("p");
  status.setAttribute("role", "status");
  const storage = element("p");
  storage.setAttribute("role", "status");
  const panel = element("section", undefined, "fieldbook-card fieldbook-review-panel");
  panel.hidden = true;
  mount.replaceChildren(settings, status, storage, panel);
  let pending = [], size = 0, attempts = 0;
  const rated = new Set();

  function setTags() {
    const previous = tagSelect.value;
    const selected = deckSelect.value;
    const source = selected ? decks.filter(deck => deck.id === selected) : decks;
    const totals = new Map();
    for (const deck of source) {
      for (const [tag, count] of Object.entries(deck.tags)) totals.set(tag, (totals.get(tag) ?? 0) + count);
    }
    tagSelect.replaceChildren(new Option("All tags", ""), ...[...totals.keys()].sort().map(tag =>
      new Option(`${tag} (${totals.get(tag)})`, tag)));
    if (totals.has(previous)) tagSelect.value = previous;
  }

  function matching() {
    return allCards.filter(card => (!deckSelect.value || card.deck === deckSelect.value) &&
      (!tagSelect.value || card.tags.includes(tagSelect.value)));
  }

  function preview(message = "") {
    const cards = matching();
    const records = readRecords();
    const now = Date.now();
    const count = selectDue(cards, records, now, cards.length).length;
    start.disabled = !count;
    let text = `${count} due or new of ${cards.length} matching cards.`;
    if (!cards.length) text = "No cards match these filters.";
    else if (!count) {
      const next = Math.min(...cards.map(card => records[card.id].due));
      text += ` Next due: ${formatDate.format(next)} (local time).`;
    }
    status.textContent = message ? `${message} ${text}` : text;
  }

  function lock(locked) {
    for (const node of [deckSelect, tagSelect, limitSelect, start, refresh]) node.disabled = locked;
  }

  function startRound() {
    pending = selectDue(matching(), readRecords(), Date.now(), Number(limitSelect.value))
      .map(card => ({card, retry: false}));
    if (!pending.length) {
      preview();
      return;
    }
    size = pending.length;
    attempts = 0;
    rated.clear();
    panel.hidden = false;
    lock(true);
    showCard();
  }

  function endRound(finished) {
    pending = [];
    panel.replaceChildren();
    panel.hidden = true;
    lock(false);
    preview(`Round ${finished ? "complete" : "ended"}: ${rated.size}/${size} cards rated in ${attempts} attempts.`);
    (start.disabled ? refresh : start).focus();
  }

  function showCard() {
    const entry = pending[0];
    if (!entry) {
      endRound(true);
      return;
    }
    const {card, retry} = entry;
    status.textContent = `${rated.size}/${size} distinct cards rated · ${pending.length} remaining exposure${pending.length === 1 ? "" : "s"}.`;
    const heading = element("h2", retry ? "Retry card" : "Review card");
    heading.tabIndex = -1;
    const answer = element("details");
    const grades = element("div", undefined, "fieldbook-actions");
    let graded = false;
    function submit(grade) {
      if (graded || !answer.open) return;
      graded = true;
      const stored = saveRecord(card, grade, Date.now());
      storage.textContent = stored ? "" : "Browser storage is unavailable. Grades will last on this page only.";
      pending.shift();
      if (grade === "again" && !retry && pending.length) pending.push({card, retry: true});
      attempts++;
      rated.add(card.id);
      showCard();
    }
    grades.append(button("Again", () => submit("again")), button("Recalled", () => submit("recalled"), true));
    answer.append(element("summary", "Reveal answer"), element("p", card.back, "fieldbook-prose"), grades);
    const footer = element("div", undefined, "fieldbook-actions");
    const topic = element("a", "Open topic reference");
    topic.href = new URL(`docs/${card.deck}/`, base);
    footer.append(button("End round", () => endRound(false)), topic);
    panel.replaceChildren(heading, element("p", `${card.title} · ${card.tags.join(" · ")}`, "fieldbook-tags"),
      element("p", card.front, "fieldbook-prose"), answer, footer);
    heading.focus();
  }

  deckSelect.addEventListener("change", () => { setTags(); preview(); });
  tagSelect.addEventListener("change", () => preview());
  limitSelect.addEventListener("change", () => preview());
  window.addEventListener("storage", event => {
    if ((event.key === key || event.key === null) && panel.hidden) preview();
  });
  setTags();
  preview();
}

const mount = document.querySelector("[data-fieldbook-review-queue]");
if (mount) {
  try {
    const response = await fetch(new URL("data/flashcard-decks.json", base));
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (data.version !== 1 || !data.decks?.length) throw new Error("Flashcard data unavailable");
    mountQueue(mount, data.decks);
  } catch {
    mount.replaceChildren(element("p", "Could not load the review queue. Reload this page or use the deck downloads below."));
  }
}
